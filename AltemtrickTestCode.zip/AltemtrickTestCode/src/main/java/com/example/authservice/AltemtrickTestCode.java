package com.example.authservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AltemtrickTestCode {

	public static void main(String[] args) {
		SpringApplication.run(AltemtrickTestCode.class, args);
	}

}
