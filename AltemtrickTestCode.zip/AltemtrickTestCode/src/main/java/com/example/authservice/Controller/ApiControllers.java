package com.example.authservice.Controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.authservice.model.User;
import com.example.authservice.repo.UserRepo;
import com.example.authservice.service.UserService;

@RestController
@RequestMapping("/api/users")
public class ApiControllers 
{
	 @Autowired
	    private UserService userService;
	 
	 @Autowired
	    private UserRepo userRepo;

	    @PostMapping("/register")
	    public User registerUser(@RequestBody User user) {
	        return userService.save(user);
	    }

	    @GetMapping("/login")
	    public User loginUser(@RequestParam String username, @RequestParam String password) {
	        User user = userService.findByUsername(username);
	        if (user != null && user.getPassword().equals(password)) {
	            return user;
	        } else {
	            return null;
	        }
	    }
	    
	    @GetMapping(value="{id}")
	    public ResponseEntity<User> getUserById(@PathVariable("id") Long id)
	    {
	    	
	    	 Optional<User> opt = userRepo.findById(id);
	    	 User updatedUser = opt.get();
	    	 return new ResponseEntity<User>(updatedUser, HttpStatus.OK);
	    }
	    
	   
//	    @GetMapping("/user/{id}")
//	    public Optional<User> getUserByUsername(@RequestParam Long id) {
//	        return userRepo.findById(id);
//	    }
}