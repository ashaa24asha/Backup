package com.example.authservice.service;

import com.example.authservice.model.User;

public interface UserService {
	User findByUsername(String username);
    User save(User user);

}
